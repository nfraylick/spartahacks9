
import requests

access_token = 'YOUR_ACCESS_TOKEN'
user_id = 'USER_ID'

url = f'https://graph.instagram.com/v13.0/{user_id}/media'
params = {'access_token': access_token}

response = requests.get(url, params=params)

if response.status_code == 200:
    data = response.json()
    # Process the data as needed
    print(data)
else:
    print(f"Error: {response.status_code} - {response.text}")