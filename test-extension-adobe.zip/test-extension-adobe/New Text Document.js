document.addEventListener("DOMContentLoaded", function() {
  const closeButton = document.getElementById("closeButton");

  closeButton.addEventListener("click", function() {
    // Add your logic here when the button is clicked
    // For simplicity, let's just close the panel
    require("uxp").storage.local.get("panel").then((result) => {
      const panel = result.panel;
      panel.close();
    });
  });
});